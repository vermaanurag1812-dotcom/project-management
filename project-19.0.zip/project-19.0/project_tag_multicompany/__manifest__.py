# Copyright 2024 Tecnativa - Víctor Martínez
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).
{
    "name": "Project Tag Multicompany",
    "version": "19.0.1.0.0",
    "category": "Project Management",
    "website": "https://github.com/OCA/project",
    "author": "Tecnativa, Odoo Community Association (OCA)",
    "license": "AGPL-3",
    "depends": ["project"],
    "installable": True,
    "data": [
        "security/project_tags_security.xml",
        "views/project_tags_views.xml",
    ],
    "maintainers": ["victoralmau"],
}
